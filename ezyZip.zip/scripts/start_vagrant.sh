#!/bin/bash
vagrant plugin install vagrant-vbguest
vagrant up
