#!/bin/bash
echo "date=`date +%F`"
