#!/usr/bin/env python3
"""
Mac VM Automation using Vagrant + VMware Fusion
"""

import subprocess
import time
import paramiko
from pathlib import Path


class VagrantVM:
    def __init__(self, vagrant_dir="."):
        self.vagrant_dir = Path(vagrant_dir)
        self.vm_info = {}
        
    def run_vagrant_command(self, command):
        """Run vagrant command and return output"""
        result = subprocess.run(
            command,
            cwd=self.vagrant_dir,
            capture_output=True,
            text=True,
            shell=True
        )
        return result
    
    def up(self):
        """Start VM"""
        print("🚀 Starting VM with Vagrant...")
        result = self.run_vagrant_command("vagrant up --provider=vmware_desktop")
        
        if result.returncode == 0:
            print("✅ VM started successfully\n")
            self.get_ssh_config()
            return True
        else:
            print(f"❌ Error: {result.stderr}")
            return False
    
    def halt(self):
        """Stop VM"""
        print("⏸️  Stopping VM...")
        result = self.run_vagrant_command("vagrant halt")
        
        if result.returncode == 0:
            print("✅ VM stopped")
            return True
        else:
            print(f"❌ Error: {result.stderr}")
            return False
    
    def destroy(self, force=True):
        """Destroy VM"""
        print("🗑️  Destroying VM...")
        cmd = "vagrant destroy"
        if force:
            cmd += " -f"
        
        result = self.run_vagrant_command(cmd)
        
        if result.returncode == 0:
            print("✅ VM destroyed successfully\n")
            return True
        else:
            print(f"❌ Error: {result.stderr}")
            return False
    
    def status(self):
        """Check VM status"""
        result = self.run_vagrant_command("vagrant status")
        print(result.stdout)
    
    def get_ssh_config(self):
        """Get SSH configuration"""
        result = self.run_vagrant_command("vagrant ssh-config")
        
        # Parse SSH config
        for line in result.stdout.split('\n'):
            line = line.strip()
            if 'HostName' in line:
                self.vm_info['host'] = line.split()[1]
            elif 'Port' in line:
                self.vm_info['port'] = int(line.split()[1])
            elif 'User' in line:
                self.vm_info['username'] = line.split()[1]
            elif 'IdentityFile' in line:
                # Handle paths with spaces - get everything after IdentityFile
                key_path = line.split('IdentityFile', 1)[1].strip().strip('"')
                self.vm_info['key_file'] = key_path
        
        print(f"📡 VM SSH Info:")
        print(f"   Host: {self.vm_info.get('host', 'N/A')}")
        print(f"   Port: {self.vm_info.get('port', 'N/A')}")
        print(f"   User: {self.vm_info.get('username', 'N/A')}")
        print(f"   Key:  {self.vm_info.get('key_file', 'N/A')}\n")
    
    def ssh_connect(self):
        """Create SSH connection using Paramiko"""
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        
        try:
            client.connect(
                hostname=self.vm_info['host'],
                port=self.vm_info['port'],
                username=self.vm_info['username'],
                key_filename=self.vm_info['key_file'],
                timeout=10
            )
            return client
        except Exception as e:
            print(f"❌ SSH Connection error: {e}")
            return None
    
    def run_commands(self, commands):
        """Execute commands via SSH"""
        print("🔧 Running commands via SSH...\n")
        
        client = self.ssh_connect()
        if not client:
            return False
        
        try:
            for cmd in commands:
                print(f"💻 Executing: {cmd}")
                stdin, stdout, stderr = client.exec_command(cmd)
                
                output = stdout.read().decode()
                error = stderr.read().decode()
                
                if output:
                    print(f"{output}")
                if error:
                    print(f"⚠️  {error}")
                print("-" * 60)
            
            return True
            
        except Exception as e:
            print(f"❌ Command execution error: {e}")
            return False
        finally:
            client.close()
    
    def transfer_file(self, local_path, remote_path):
        """Transfer file to VM using SFTP"""
        print(f"📤 Transferring {local_path} → {remote_path}")
        
        transport = paramiko.Transport((self.vm_info['host'], self.vm_info['port']))
        
        try:
            pkey = paramiko.RSAKey.from_private_key_file(self.vm_info['key_file'])
            transport.connect(username=self.vm_info['username'], pkey=pkey)
            
            sftp = paramiko.SFTPClient.from_transport(transport)
            sftp.put(local_path, remote_path)
            
            print(f"✅ File transferred successfully\n")
            sftp.close()
            return True
            
        except Exception as e:
            print(f"❌ Transfer error: {e}")
            return False
        finally:
            transport.close()


def main():
    """Main automation workflow"""
    
    print("=" * 60)
    print("  VM AUTOMATION - Vagrant + VMware Fusion on Mac")
    print("=" * 60)
    print()
    
    # Initialize VM
    vm = VagrantVM()
    
    try:
        # Step 1: Start VM
        if not vm.up():
            return
        
        # Wait for VM to be ready
        print("⏳ Waiting for VM to be fully ready...")
        time.sleep(15)
        
        # Step 2: Run system commands
        print("\n" + "=" * 60)
        print("  RUNNING SYSTEM COMMANDS")
        print("=" * 60 + "\n")
        
        commands = [
            'hostname',
            'uname -a',
            'cat /etc/os-release | head -5',
            'ip addr show',
            'df -h | head -5',
            'free -h',
            'python3 --version'
        ]
        
        vm.run_commands(commands)
        
        # Step 3: Optional - Transfer file example
        # vm.transfer_file('local_file.txt', '/tmp/remote_file.txt')
        
        # Step 4: Keep or destroy
        print("\n" + "=" * 60)
        print("  VM IS RUNNING")
        print("=" * 60)
        print(f"\nSSH: vagrant ssh")
        print(f"Or:  ssh -p {vm.vm_info['port']} {vm.vm_info['username']}@{vm.vm_info['host']}\n")
        
        choice = input("❓ Destroy VM now? (y/n): ").strip().lower()
        
        if choice == 'y':
            vm.destroy()
        else:
            print("\n✅ VM kept running. To destroy later:")
            print("   vagrant destroy -f\n")
    
    except KeyboardInterrupt:
        print("\n\n⚠️  Interrupted by user")
        choice = input("Destroy VM? (y/n): ").strip().lower()
        if choice == 'y':
            vm.destroy()
    
    except Exception as e:
        print(f"\n❌ Error: {e}")
        choice = input("Destroy VM? (y/n): ").strip().lower()
        if choice == 'y':
            vm.destroy()


if __name__ == "__main__":
    main()